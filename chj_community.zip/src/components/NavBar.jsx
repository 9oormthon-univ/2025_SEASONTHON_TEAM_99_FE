
import { Link, useLocation } from 'react-router-dom'

export default function NavBar(){
  const { pathname } = useLocation()
  const isActive = (p) => pathname.startsWith(p)

  return (
    <header className="site-header">
      <div className="container header-container">
        <div className="header-left">
          <Link to="/" className="logo" aria-label="홈으로">
            <img src="/theme/images/331949fc8103c09cbfad32b570d0d77119d1bfd6.png" alt="청정 logo icon" className="logo-icon" />
            <img src="/theme/images/I5070_8867_5070_11111_4989_645.svg" alt="청정" className="logo-text" />
          </Link>

          <nav className="main-nav" aria-label="주요 탭">
            <ul>
              <li><Link className={isActive('/policy') ? 'active' : ''} to="/policy">정책보기</Link></li>
              <li><Link className={isActive('/community') ? 'active' : ''} to="/community">커뮤니티</Link></li>
              <li><Link className={isActive('/report') ? 'active' : ''} to="/report">레포트</Link></li>
            </ul>
          </nav>
        </div>

        <div className="user-profile">
          <div className="user-icon-wrapper" aria-hidden="true">
            <img src="/theme/images/I5070_8867_5070_11146_5070_11031_160_1920.svg" alt="" className="user-icon-bg" />
            <img src="/theme/images/I5070_8867_5070_11146_5070_11031_160_1918.svg" alt="" className="user-icon-head" />
            <div className="user-icon-body"></div>
          </div>
          <button className="btn" type="button">로그인</button>
        </div>
      </div>
    </header>
  )
}
