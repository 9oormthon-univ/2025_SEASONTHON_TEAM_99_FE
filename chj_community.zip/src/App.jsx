import { Routes, Route, Navigate } from 'react-router-dom'
import NavBar from './components/NavBar.jsx'
import CommunityList from './features/community/pages/CommunityList.jsx'
import NewPost from './features/community/pages/NewPost.jsx'
import PostDetail from './features/community/pages/PostDetail.jsx'

export default function App(){
  return (
    <>
      <NavBar />
      <Routes>
        <Route path="/" element={<Navigate to="/community" replace />} />
        <Route path="/community" element={<CommunityList />} />
        <Route path="/community/new" element={<NewPost />} />
        <Route path="/community/:id" element={<PostDetail />} />
        <Route path="*" element={<div className="container">페이지가 없습니다.</div>} />
      </Routes>
      <footer className="site-footer"><div className="container">© {new Date().getFullYear()} 청정</div></footer>
    </>
  )
}
