
import { Link } from 'react-router-dom'

function fmt(dateStr){
  const d = new Date(dateStr)
  const yyyy = d.getFullYear()
  const mm = String(d.getMonth()+1).padStart(2,'0')
  const dd = String(d.getDate()).padStart(2,'0')
  return `${yyyy}.${mm}.${dd}`
}

export default function PostCard({ post }){
  const tag = ['#', [post.region, post.city].filter(Boolean).join(' ')].join(' ').trim()
  return (
    <article className="post-card">
      {post.images?.[0] && (
        <div className="post-image-wrapper">
          <img className="post-image" src={post.images[0]} alt="" />
        </div>
      )}
      <div className="post-content">
        <div className="post-badge">{tag || '#지역'}</div>
        <h3 className="post-title"><Link to={`/community/${post.id}`}>{post.title}</Link></h3>
        <p className="post-desc">{post.content}</p>
        <div className="post-meta">
          <div className="likes">
            <img src="/theme/images/I5062_4400_5031_5339_5031_4698.svg" alt="" className="like-icon" />
            <span className="likes-count-red">{post.likes || 0}</span>
          </div>
          <time dateTime={new Date(post.createdAt).toISOString()}>{fmt(post.createdAt)}</time>
        </div>
      </div>
    </article>
  )
}
