import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { listPosts } from "../api/posts";

// 하트 아이콘 SVG 컴포넌트
const HeartIcon = () => (
  <svg className="heart-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* 빈 하트 (테두리) */}
    <path className="heart-empty" d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.32998C13.01 3.97998 14.62 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    {/* 채워진 하트 */}
    <path className="heart-filled" d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.32998C13.01 3.97998 14.62 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" />
  </svg>
);


export default function CommunityList() {
  const LIMIT = 10;
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    load(true);
  }, []);

  async function load(reset = false) {
    setLoading(true);
    const offset = reset ? 0 : items.length;
    const { items: chunk, total } = await listPosts({ offset, limit: LIMIT });
    
    const newItems = chunk.map(item => ({ ...item, isLiked: false }));

    setItems(reset ? newItems : [...items, ...newItems]);
    setTotal(total);
    setLoading(false);
  }

  const handleLikeClick = (e, postId) => {
    e.stopPropagation();
    e.preventDefault();

    setItems(items.map(item => 
      item.id === postId ? { ...item, isLiked: !item.isLiked, likes: item.isLiked ? item.likes - 1 : item.likes + 1 } : item
    ));
  };

  const handleItemClick = (id) => {
    navigate(`/community/${id}`);
  };

  return (
    <div className="container">
      {/* 상단 헤더 */}
      <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '28px 0 16px'}}>
        <h1 className="page-title" style={{textAlign: 'left', margin: 0}}>커뮤니티</h1>
        <Link to="/community/new" className="btn primary">글 작성</Link>
      </div>

      {/* 게시글 리스트 */}
      <div className="post-list">
        {items.map((p) => (
          <div key={p.id} className="post-item" onClick={() => handleItemClick(p.id)} style={{cursor: 'pointer'}}>
            
            {/* 왼쪽: 제목 + 좋아요 (✨ 변경된 부분) */}
            <div className="post-item-left">
              <span className="post-item-title">{p.title}</span>
              <span className={`post-item-likes ${p.isLiked ? 'liked' : ''}`} onClick={(e) => handleLikeClick(e, p.id)}>
                <HeartIcon />
                <span>{p.likes || 0}</span>
              </span>
            </div>

            {/* 오른쪽: 작성일 + 지역 (✨ 변경된 부분) */}
            <div className="post-item-right">
              <span>{new Date(p.createdAt).toISOString().slice(0, 10).replaceAll('-', '.')}</span>
              <span className="badge">#{ p.region}</span> 
            </div>
            
          </div>
        ))}
      </div>

      {/* 더 보기 버튼 */}
      <div className="load-more-container">
        {items.length < total && (
          <button onClick={() => load()} disabled={loading} className="load-more-btn">
            {loading ? "불러오는 중..." : "더 보기"}
          </button>
        )}
      </div>
    </div>
  );
}