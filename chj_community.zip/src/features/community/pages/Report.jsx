export default function Report(){
  return (
    <div className="container">
      <div className="page-title">레포트</div>
      <div className="empty">준비 중입니다.</div>
    </div>
  )
}