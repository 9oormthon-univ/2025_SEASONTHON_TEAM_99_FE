
import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { listPosts } from "../api/posts";
import PostCard from "../components/PostCard";

const REGIONS = [
  { code: '11', label: '서울특별시' },
  { code: '26', label: '부산광역시' },
  { code: '27', label: '대구광역시' },
  { code: '28', label: '인천광역시' },
  { code: '29', label: '광주광역시' },
  { code: '30', label: '대전광역시' },
  { code: '31', label: '울산광역시' },
  { code: '36', label: '세종특별자치시' },
  { code: '41', label: '경기도' },
  { code: '42', label: '강원특별자치도' },
  { code: '43', label: '충청북도' },
  { code: '44', label: '충청남도' },
  { code: '45', label: '전북특별자치도' },
  { code: '46', label: '전라남도' },
  { code: '47', label: '경상북도' },
  { code: '48', label: '경상남도' },
  { code: '49', label: '세종특별자치시' },
  { code: '50', label: '제주특별자치도' },
];

// NOTE: kept from original app (trimmed for brevity here).
// For the themed version, we only need to keep the shape: { [regionCode]: [{code,label}, ...] }
const CITIES_BY_REGION = {
  '11': [{ code: '강남구', label: '강남구' }, { code: '강북구', label: '강북구' }],
  '26': [{ code: '해운대구', label: '해운대구' }],
};

export default function CommunityList() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [region, setRegion] = useState("");
  const [city, setCity] = useState("");
  const [sort, setSort] = useState("likes"); // 'likes' | 'latest'

  useEffect(() => {
    // ensure seed data exists (original app behavior)
    listPosts();
  }, []);

  const posts = useMemo(() => {
    let arr = listPosts();
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      arr = arr.filter(p => (p.title+p.content).toLowerCase().includes(q));
    }
    if (region) arr = arr.filter(p => p.region === region);
    if (city) arr = arr.filter(p => p.city === city);

    if (sort === 'likes') {
      arr = [...arr].sort((a,b) => (b.likes||0) - (a.likes||0));
    } else {
      arr = [...arr].sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
    }
    return arr;
  }, [search, region, city, sort]);

  const cities = CITIES_BY_REGION[region] || [];

  return (
    <main>
      {/* Hero / Title */}
      <section className="section hero">
        <div className="container hero-container">
          <div className="hero-inner">
            <div className="breadcrumbs" aria-label="breadcrumb">
              <span>홈</span>
              <span aria-hidden="true"> &gt; </span>
              <strong>커뮤니티</strong>
            </div>
            <h1 className="page-title">커뮤니티</h1>
            <p className="page-subtitle">청정 지역 정보를 자유롭게 공유하세요.</p>
          </div>
        </div>
      </section>

      {/* Filters / Actions */}
      <section className="section list-controls">
        <div className="container">
          <div className="controls-row">
            <div className="filters">
              <input
                className="search-input"
                placeholder="검색어를 입력하세요"
                value={search}
                onChange={(e)=>setSearch(e.target.value)}
                aria-label="검색"
              />
              <select
                className="filter-select"
                value={region}
                onChange={(e)=>{ setRegion(e.target.value); setCity(''); }}
                aria-label="지역 선택"
              >
                <option value="">지역</option>
                {REGIONS.map(r => <option key={r.code} value={r.label}>{r.label}</option>)}
              </select>
              <select
                className="filter-select"
                value={city}
                onChange={(e)=>setCity(e.target.value)}
                aria-label="도시 선택"
                disabled={!region}
              >
                <option value="">도시</option>
                {cities.map(c => <option key={c.code} value={c.label}>{c.label}</option>)}
              </select>
            </div>

            <div className="actions-group">
              <div className="sort-group" role="tablist" aria-label="정렬">
                <button
                  className={`sort-btn ${sort==='latest' ? 'active' : ''}`}
                  onClick={()=>setSort('latest')}
                  type="button"
                >
                  <img src="/theme/images/I5062_4399_5031_5336_5031_4676.svg" alt="" />
                  <span>최신순</span>
                </button>
                <button
                  className={`sort-btn ${sort==='likes' ? 'active' : ''}`}
                  onClick={()=>setSort('likes')}
                  type="button"
                >
                  <img src="/theme/images/I5062_4400_5031_5339_5031_4698.svg" alt="" />
                  <span>좋아요순</span>
                </button>
              </div>

              <Link to="/community/new" className="primary-button">글쓰기</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Posts grid */}
      <section className="section">
        <div className="container">
          <ul className="post-list">
            {posts.map(p => (
              <li key={p.id} className="post-item">
                <PostCard post={p} />
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Pagination placeholder (kept for visual parity) */}
      <section id="pagination" className="section">
        <div className="container">
          <nav className="pagination" aria-label="페이지네이션">
            <button className="page-btn" disabled>이전</button>
            <div className="page-numbers">
              <button className="page-btn current">1</button>
              <button className="page-btn">2</button>
              <button className="page-btn">3</button>
            </div>
            <button className="page-btn">다음</button>
          </nav>
        </div>
      </section>
    </main>
  );
}
