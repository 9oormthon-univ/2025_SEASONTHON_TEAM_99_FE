import { useRef, useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { createPost } from '../api/posts'

const REGIONS = [
  { code: '11', label: '서울특별시' },
  { code: '26', label: '부산광역시' },
  { code: '27', label: '대구광역시' },
  { code: '28', label: '인천광역시' },
  { code: '29', label: '광주광역시' },
  { code: '30', label: '대전광역시' },
  { code: '31', label: '울산광역시' },
  { code: '36', label: '세종특별자치시' },
  { code: '41', label: '경기도' },
  { code: '51', label: '강원특별자치도' },
  { code: '43', label: '충청북도' },
  { code: '44', label: '충청남도' },
  { code: '45', label: '전북특별자치도' },
  { code: '46', label: '전라남도' },
  { code: '47', label: '경상북도' },
  { code: '48', label: '경상남도' },
  { code: '50', label: '제주특별자치도' },
]

const CITIES_BY_REGION = {
'11': [ // 서울특별시
    { code: '종로구', label: '종로구' },
    { code: '중구', label: '중구' },
    { code: '용산구', label: '용산구' },
    { code: '성동구', label: '성동구' },
    { code: '광진구', label: '광진구' },
    { code: '동대문구', label: '동대문구' },
    { code: '중랑구', label: '중랑구' },
    { code: '성북구', label: '성북구' },
    { code: '강북구', label: '강북구' },
    { code: '도봉구', label: '도봉구' },
    { code: '노원구', label: '노원구' },
    { code: '은평구', label: '은평구' },
    { code: '서대문구', label: '서대문구' },
    { code: '마포구', label: '마포구' },
    { code: '양천구', label: '양천구' },
    { code: '강서구', label: '강서구' },
    { code: '구로구', label: '구로구' },
    { code: '금천구', label: '금천구' },
    { code: '영등포구', label: '영등포구' },
    { code: '동작구', label: '동작구' },
    { code: '관악구', label: '관악구' },
    { code: '서초구', label: '서초구' },
    { code: '강남구', label: '강남구' },
    { code: '송파구', label: '송파구' },
    { code: '강동구', label: '강동구' },
  ],

  '26': [ // 부산광역시
    { code: '중구', label: '중구' },
    { code: '서구', label: '서구' },
    { code: '동구', label: '동구' },
    { code: '영도구', label: '영도구' },
    { code: '부산진구', label: '부산진구' },
    { code: '동래구', label: '동래구' },
    { code: '남구', label: '남구' },
    { code: '북구', label: '북구' },
    { code: '해운대구', label: '해운대구' },
    { code: '사하구', label: '사하구' },
    { code: '금정구', label: '금정구' },
    { code: '강서구', label: '강서구' },
    { code: '연제구', label: '연제구' },
    { code: '수영구', label: '수영구' },
    { code: '사상구', label: '사상구' },
    { code: '기장군', label: '기장군' },
  ],

  '27': [ // 대구광역시
    { code: '중구', label: '중구' },
    { code: '동구', label: '동구' },
    { code: '서구', label: '서구' },
    { code: '남구', label: '남구' },
    { code: '북구', label: '북구' },
    { code: '수성구', label: '수성구' },
    { code: '달서구', label: '달서구' },
    { code: '달성군', label: '달성군' },
  ],

  '28': [ // 인천광역시
    { code: '중구', label: '중구' },
    { code: '동구', label: '동구' },
    { code: '미추홀구', label: '미추홀구' },
    { code: '연수구', label: '연수구' },
    { code: '남동구', label: '남동구' },
    { code: '부평구', label: '부평구' },
    { code: '계양구', label: '계양구' },
    { code: '서구', label: '서구' },
    { code: '강화군', label: '강화군' },
    { code: '옹진군', label: '옹진군' },
  ],

  '29': [ // 광주광역시
    { code: '동구', label: '동구' },
    { code: '서구', label: '서구' },
    { code: '남구', label: '남구' },
    { code: '북구', label: '북구' },
    { code: '광산구', label: '광산구' },
  ],

  '30': [ // 대전광역시
    { code: '동구', label: '동구' },
    { code: '중구', label: '중구' },
    { code: '서구', label: '서구' },
    { code: '유성구', label: '유성구' },
    { code: '대덕구', label: '대덕구' },
  ],

  '31': [ // 울산광역시
    { code: '중구', label: '중구' },
    { code: '남구', label: '남구' },
    { code: '동구', label: '동구' },
    { code: '북구', label: '북구' },
    { code: '울주군', label: '울주군' },
  ],



  // 경기도
  '41': [
    { code: '수원시', label: '수원시' },
    { code: '성남시', label: '성남시' },
    { code: '의정부시', label: '의정부시' },
    { code: '안양시', label: '안양시' },
    { code: '부천시', label: '부천시' },
    { code: '광명시', label: '광명시' },
    { code: '평택시', label: '평택시' },
    { code: '동두천시', label: '동두천시' },
    { code: '안산시', label: '안산시' },
    { code: '고양시', label: '고양시' },
    { code: '과천시', label: '과천시' },
    { code: '구리시', label: '구리시' },
    { code: '남양주시', label: '남양주시' },
    { code: '오산시', label: '오산시' },
    { code: '시흥시', label: '시흥시' },
    { code: '군포시', label: '군포시' },
    { code: '의왕시', label: '의왕시' },
    { code: '하남시', label: '하남시' },
    { code: '용인시', label: '용인시' },
    { code: '파주시', label: '파주시' },
    { code: '이천시', label: '이천시' },
    { code: '안성시', label: '안성시' },
    { code: '김포시', label: '김포시' },
    { code: '화성시', label: '화성시' },
    { code: '광주시', label: '광주시' },
    { code: '양주시', label: '양주시' },
    { code: '포천시', label: '포천시' },
    { code: '여주시', label: '여주시' },
  ],

  // 강원도
  '51': [
    { code: '춘천시', label: '춘천시' },
    { code: '원주시', label: '원주시' },
    { code: '강릉시', label: '강릉시' },
    { code: '동해시', label: '동해시' },
    { code: '태백시', label: '태백시' },
    { code: '속초시', label: '속초시' },
    { code: '삼척시', label: '삼척시' },
  ],

  //충북
  '43': [
    { code: '청주시', label: '청주시' },
    { code: '충주시', label: '충주시' },
    { code: '제천시', label: '제천시' },
  ],

  //충남
  '44': [
    { code: '천안시', label: '천안시' },
    { code: '공주시', label: '공주시' },
    { code: '보령시', label: '보령시' },
    { code: '아산시', label: '아산시' },
    { code: '서산시', label: '서산시' },
    { code: '논산시', label: '논산시' },
    { code: '계룡시', label: '계룡시' },
    { code: '당진시', label: '당진시' },
  ],

  //전북
  '45': [
    { code: '전주시', label: '전주시' },
    { code: '군산시', label: '군산시' },
    { code: '익산시', label: '익산시' },
    { code: '정읍시', label: '정읍시' },
    { code: '남원시', label: '남원시' },
    { code: '김제시', label: '김제시' },
  ],

  //전남
  '46': [
    { code: '목포시', label: '목포시' },
    { code: '여수시', label: '여수시' },
    { code: '순천시', label: '순천시' },
    { code: '나주시', label: '나주시' },
    { code: '광양시', label: '광양시' },
  ],

  //경북
  '47': [
    { code: '포항시', label: '포항시' },
    { code: '경주시', label: '경주시' },
    { code: '김천시', label: '김천시' },
    { code: '안동시', label: '안동시' },
    { code: '구미시', label: '구미시' },
    { code: '영주시', label: '영주시' },
    { code: '영천시', label: '영천시' },
    { code: '상주시', label: '상주시' },
    { code: '문경시', label: '문경시' },
    { code: '경산시', label: '경산시' },
  ],

  // 경남
  '48': [
    { code: '창원시', label: '창원시' },
    { code: '진주시', label: '진주시' },
    { code: '통영시', label: '통영시' },
    { code: '사천시', label: '사천시' },
    { code: '김해시', label: '김해시' },
    { code: '밀양시', label: '밀양시' },
    { code: '거제시', label: '거제시' },
    { code: '양산시', label: '양산시' },
  ],

  // 제주
  '50': [
    { code: '제주시', label: '제주시' },
    { code: '서귀포시', label: '서귀포시' },
  ],
}



export default function NewPost(){
  const nav = useNavigate()
  const [title,setTitle] = useState('')
  const [region,setRegion] = useState('')     // region code
  const [city,setCity] = useState('')         // city code
  const [content,setContent] = useState('')
  const [images,setImages] = useState([])
  const [submitting,setSubmitting] = useState(false)
  const fileRef = useRef()

  const cities = useMemo(()=> (region ? (CITIES_BY_REGION[region] || []) : []), [region])
  const ready = title.trim() && region && city

  function onFiles(files){
    const list = Array.from(files || []).slice(0, 3 - images.length)
    if(!list.length) return
    const readers = list.map(f => new Promise(res => {
      const r = new FileReader()
      r.onload = () => res(r.result)
      r.readAsDataURL(f)
    }))
    Promise.all(readers).then(ds => setImages(prev => [...prev, ...ds].slice(0,3)))
  }

  async function submit(e){
    e.preventDefault()
    if(!ready) return
    setSubmitting(true)

    // 백엔드에 코드와 라벨을 같이 저장하고 싶다면, 라벨은 조회해서 보냅니다.
    const regionLabel = REGIONS.find(r => r.code === region)?.label || ''
    const cityLabel = cities.find(c => c.code === city)?.label || ''

    const saved = await createPost({
      title,
      regionCode: region,  // 코드 저장 권장
      region: regionLabel, // 사람 읽는 용도
      cityCode: city,
      city: cityLabel,
      content,
      images
    })

    setSubmitting(false)
    nav(`/community/${saved.id}`)
  }

  return (
    <div className="container">
      <div className="page-title">글 작성</div>
      <div className="hr" />

      <form onSubmit={submit} style={{display:'grid',gap:18}}>
        <div className="grid-2">
          <div>
            <label className="label">제목</label>
            <input className="input" placeholder="제목을 입력해주세요." value={title} onChange={e=>setTitle(e.target.value)} />
          </div>

          <div>
            <label className="label">지역</label>
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:8}}>
              {/* 1차: 광역시/도 */}
              <select
                className="select"
                value={region}
                onChange={e=>{
                  setRegion(e.target.value)
                  setCity('') // 중요: 상위가 바뀌면 하위 초기화
                }}
              >
                <option value="">(광역시/도 선택)</option>
                {REGIONS.map(r => <option key={r.code} value={r.code}>{r.label}</option>)}
              </select>

              {/* 2차: 시 */}
              <select
                className="select"
                value={city}
                onChange={e=>setCity(e.target.value)}
                disabled={!region}
              >
                <option value="">{region ? '(시 선택)' : '먼저 광역시/도를 선택하세요'}</option>
                {cities.map(c => <option key={c.code} value={c.code}>{c.label}</option>)}
              </select>
            </div>
          </div>
        </div>

        <div>
          <label className="label">본문</label>
          <textarea className="textarea" placeholder="본문을 입력해주세요." value={content} onChange={e=>setContent(e.target.value)} />
        </div>

        <div>
          <label className="label">사진 업로드 (최대 3장)</label>
          <div className="drop" onDragOver={(e)=>e.preventDefault()} onDrop={(e)=>{e.preventDefault(); onFiles(e.dataTransfer.files)}}>
            이미지를 드롭하거나 클릭해서 선택하세요
            <div style={{marginTop:10}}>
              <button type="button" className="btn ghost" onClick={()=>fileRef.current?.click()}>파일 선택</button>
            </div>
            <input ref={fileRef} type="file" accept="image/*" multiple style={{display:'none'}} onChange={(e)=>onFiles(e.target.files)} />
          </div>
          {!!images.length && <div className="previews">{images.map((src,i)=><img key={i} className="preview" src={src} alt={`preview-${i}`} />)}</div>}
        </div>

        <div style={{display:'flex',justifyContent:'flex-end',gap:10}}>
          <button type="button" className="btn ghost" onClick={()=>nav(-1)}>뒤로가기</button>
          <button className="btn primary" disabled={!ready || submitting}>{submitting ? '저장 중…' : '완료'}</button>
        </div>
      </form>
    </div>
  )
}
