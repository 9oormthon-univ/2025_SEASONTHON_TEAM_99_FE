import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { addComment, deleteComment, getPost, toggleLike } from '../api/posts'
import { getAnonId } from '../api/storage'

function fmt(dateStr){
  const d = new Date(dateStr)
  const yy = d.getFullYear()
  const mm = String(d.getMonth()+1).padStart(2,'0')
  const dd = String(d.getDate()).padStart(2,'0')
  const hh = String(d.getHours()).padStart(2,'0')
  const mi = String(d.getMinutes()).padStart(2,'0')
  return `${yy}.${mm}.${dd} ${hh}:${mi}`
}

// 아이콘 SVG 컴포넌트들
const BackIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="o 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
  </svg>
);
const LikeIcon = () => (
  <svg className="like-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.32998C13.01 3.97998 14.62 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);


export default function PostDetail(){
  const { id } = useParams()
  const nav = useNavigate()
  const [post,setPost] = useState(null)
  const [loading,setLoading] = useState(true)
  const [comment,setComment] = useState('')

  useEffect(()=>{ (async()=>{ setPost(await getPost(id)); setLoading(false) })() },[id])

  // ✨ '좋아요' 로직 수정: 'Optimistic Update' (낙관적 업데이트) 적용
  async function like(){
    // 1. 서버 응답을 기다리지 않고, 화면(State)을 먼저 즉시 업데이트합니다.
    setPost(p => {
      if (!p) return null;
      const newIsLiked = !p.isLiked;
      const newLikes = newIsLiked ? (p.likes || 0) + 1 : p.likes - 1;
      return { ...p, isLiked: newIsLiked, likes: newLikes };
    });

    // 2. 그 후에 서버에 실제 업데이트를 요청합니다.
    try {
      await toggleLike(id);
    } catch (error) {
      // 3. 만약 서버 업데이트가 실패하면, 화면을 원래 상태로 되돌립니다.
      console.error("Failed to update like status:", error);
      setPost(p => {
        if (!p) return null;
        const revertedIsLiked = !p.isLiked;
        const revertedLikes = revertedIsLiked ? (p.likes || 0) + 1 : p.likes - 1;
        return { ...p, isLiked: revertedIsLiked, likes: revertedLikes };
      });
    }
  }

  async function submit(e){ e.preventDefault(); if(!comment.trim()) return; setPost(await addComment(id,{content:comment})); setComment('') }
  async function remove(cid){ setPost(await deleteComment(id,cid)) }

  const anonNumberMap = useMemo(() => {
    if (!post?.comments || post.comments.length === 0) return {};
    const firstCommentByAnonId = post.comments.reduce((acc, comment) => {
      if (!acc[comment.anonId]) acc[comment.anonId] = comment;
      return acc;
    }, {});
    const sortedAuthors = Object.values(firstCommentByAnonId)
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    return sortedAuthors.reduce((acc, comment, index) => {
      acc[comment.anonId] = index + 1;
      return acc;
    }, {});
  }, [post?.comments]);

  if(loading) return <div className="container" style={{paddingTop: 40, textAlign: 'center'}}>불러오는 중…</div>
  if(!post) return <div className="container" style={{paddingTop: 40}}>존재하지 않는 글입니다. <div style={{marginTop:8}}><Link className="btn" to="/community">목록으로</Link></div></div>

  const me = getAnonId()

  return (
    <div className="container">
      <Link to="/community" className="back-link">
        <BackIcon />
        <span>목록으로</span>
      </Link>

      <h1 className="page-title" style={{marginTop:0, textAlign:'left'}}>{post.title}</h1>
      <p className="subtitle" style={{textAlign:'left', marginTop:4}}>
        {fmt(post.createdAt)} · {[post.region, post.city].filter(Boolean).join(' ')}
      </p>
      <div className="hr" />

      {!!post.images?.length && (
        <div className="previews-large" style={{justifyContent: 'center', marginBottom: 16}}>
          {post.images.map((src,i)=><img key={i} className="preview-large" src={src} alt={`img-${i}`} />)}
        </div>
      )}

      <div style={{minHeight: 150, marginTop:16, whiteSpace:'pre-wrap', lineHeight:1.7}}>
        {post.content}
      </div>

      <div className="actions" style={{marginTop:24, justifyContent: 'center'}}>
        <button className={`like-btn-re ${post.isLiked ? 'active' : ''}`} onClick={like}>
          <LikeIcon />
          <span>좋아요 {post.likes||0}</span>
        </button>
      </div>

      <div className="hr" />

      <div className="comment-section">
        <h2 className="comment-section-header">댓글<span>{post.comments.length}</span></h2>
        
        <form onSubmit={submit} className="comment-form" style={{display:'grid', gridTemplateColumns:'1fr auto', gap:12, marginBottom:16}}>
          <input className="input" placeholder="따뜻한 댓글을 남겨주세요." value={comment} onChange={(e)=>setComment(e.target.value)} />
          <button type="submit" className="btn primary">등록</button>
        </form>

        <div>
          {post.comments.length === 0 && <div className="empty">첫 댓글을 남겨보세요!</div>}
          {post.comments.map((c) => (
            <div key={c.id} className="comment">
              <div className="comment-header">
                <div className="comment-author">
                  <span>익명 {anonNumberMap[c.anonId]}</span>
                  {c.anonId === post.anonId && <span className="author-badge owner">작성자</span>}
                </div>
                {c.anonId === me && (
                  <button className="comment-delete-btn" onClick={() => remove(c.id)}>삭제</button>
                )}
              </div>
              <div className="comment-content">{c.content}</div>
              <div className="comment-meta">{fmt(c.createdAt)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}